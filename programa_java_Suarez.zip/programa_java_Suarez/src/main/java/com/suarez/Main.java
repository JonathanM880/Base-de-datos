package com.suarez;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.suarez.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import java.util.HashMap;

// jjsuarezz -- Jonathan Suarez
public class Main {

    public static void main(String[] args) {
        DbRedis dbRedis = new DbRedis();
        dbRedis.connectToRedis("localhost", 6379);

        // DB 1: Sesiones
        String sessionHash = dbRedis.storeRandomNumberHash();

        if (dbRedis.keyExists(sessionHash)) {
            System.out.println("Sesión iniciada. Continuando con sincronización...");

            try {
                EmpleadoSyncService syncService = new EmpleadoSyncService();

                // Insertar empleados en MySQL y Redis (DB 0)
                List<Empleado> nuevosEmpleados = List.of(
                        new Empleado(900001, LocalDate.of(1985, 3, 15), "Ana", "García", "F", LocalDate.of(2010, 5, 20)),
                        new Empleado(900002, LocalDate.of(1992, 7, 8), "Luis", "Ramírez", "M", LocalDate.of(2015, 3, 10)),
                        new Empleado(900003, LocalDate.of(1988, 11, 30), "Sofía", "Martínez", "F", LocalDate.of(2018, 11, 1)),
                        new Empleado(900004, LocalDate.of(1995, 9, 12), "Diego", "Fernández", "M", LocalDate.of(2022, 2, 14)),
                        new Empleado(900005, LocalDate.of(1980, 1, 5), "Lucía", "Ortega", "F", LocalDate.of(2005, 8, 25))
                );

                for (Empleado emp : nuevosEmpleados) {
                    syncService.insertarEmpleado(emp); // DB 0
                }

                syncService.sincronizarRedisDesdeMySQL(); // DB 0

                // Procesamiento en DB 0
                RedisReaderService readerService = new RedisReaderService();
                readerService.procesarEmpleadosPorLotes("emp:", empleados -> {
                    System.out.println("Procesando lote de " + empleados.size() + " empleados");
                });
                readerService.cerrar();

            } catch (Exception e) {
                System.err.println("Error durante la ejecución: " + e.getMessage());
                e.printStackTrace();
            }

        } else {
            System.out.println("No se pudo iniciar sesión temporal. Abortando ejecución.");
        }

        dbRedis.disconnectFromRedis();
    }
}


