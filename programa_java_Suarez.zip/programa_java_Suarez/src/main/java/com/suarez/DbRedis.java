package com.suarez;
import redis.clients.jedis.Jedis;



public class DbRedis {
    private Jedis jedis;

    public void connectToRedis(String host, int port) {
        jedis = new Jedis(host, port);
        System.out.println("Connected to Redis");
    }

    public void disconnectFromRedis() {
        if (jedis != null) {
            jedis.close();
            System.out.println("Disconnected from Redis");
        }
    }

    // Método para almacenar un número aleatorio como un hash en Redis
    public String storeRandomNumberHash() {
        int randomNumber = (int) (Math.random() * Integer.MAX_VALUE);
        String hashValue = String.valueOf(randomNumber);

        if (jedis != null) {
            jedis.select(1); // Selects database 1 in Redis
            jedis.hset(hashValue, "randomNumber", hashValue);
            jedis.expire(hashValue, 60); // Set TTL of 1 minute (60 seconds)
            System.out.println("Stored hash of random number as string in Redis (DB: 1) with key: " + hashValue);
        } else {
            System.out.println("x:Redis connection is not established.");
        }

        return hashValue;
    }

    public boolean keyExists(String key) {
        if (jedis != null) {
            return jedis.exists(key);
        }
        throw new IllegalStateException("Redis connection is not established");
    }


    public static void main(String[] args) {
        DbRedis dbRedis = new DbRedis();
        dbRedis.connectToRedis("localhost", 6379); // Cambia la dirección y el puerto según tu configuración de Redis
         var hashKey = dbRedis.storeRandomNumberHash();
        System.out.println("Hash key: " + hashKey);
        System.out.println(dbRedis.keyExists(hashKey) ? "Key exists" : "Key does not exist");
        
        // Aquí puedes realizar operaciones con Redis, como agregar o recuperar datos.

        


    }
}
