package com.suarez;

public class EmpleadoSyncService {

}
