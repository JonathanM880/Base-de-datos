package com.suarez;

import java.sql.*;
import java.util.List;

import redis.clients.jedis.Jedis;

import java.io.FileWriter;
import java.io.IOException;

public class BaseDeDatosUtils {
    
    //CON ESTE METODO CREO LA TABLA EN MYSQL
    public static void crearTablaMySQL(ResultSet resultado, String nombreTabla, Connection connectionMySQL) {
        try {
            ResultSetMetaData metaData = resultado.getMetaData();
            int cantidadColumnas = metaData.getColumnCount();
    
            StringBuilder sqlCrear = new StringBuilder("CREATE TABLE IF NOT EXISTS " + nombreTabla + " (");
    
            for (int i = 1; i <= cantidadColumnas; i++) {
                String nombreColumna = metaData.getColumnName(i);
                int tipoColumna = metaData.getColumnType(i);
    
                sqlCrear.append(nombreColumna).append(" ");
    
                switch (tipoColumna) {
                    case Types.INTEGER:
                    case Types.SMALLINT:
                    case Types.TINYINT:
                        sqlCrear.append("INT");
                        break;
                    case Types.BIGINT:
                        sqlCrear.append("BIGINT");
                        break;
                    case Types.FLOAT:
                    case Types.REAL:
                    case Types.DOUBLE:
                        sqlCrear.append("DOUBLE");
                        break;
                    case Types.DECIMAL:
                    case Types.NUMERIC:
                        sqlCrear.append("DECIMAL(15,2)");
                        break;
                    case Types.DATE:
                        sqlCrear.append("DATE");
                        break;
                    case Types.TIME:
                        sqlCrear.append("TIME");
                        break;
                    case Types.TIMESTAMP:
                        sqlCrear.append("TIMESTAMP");
                        break;
                    default:
                        sqlCrear.append("VARCHAR(255)");
                }
    
                if (i < cantidadColumnas) {
                    sqlCrear.append(", ");
                }
            }
            sqlCrear.append(")");
    
            try (Statement stmt = connectionMySQL.createStatement()) {
                stmt.execute(sqlCrear.toString());
                System.out.println("Tabla '" + nombreTabla + "' creada en MySQL.");
            }
        } catch (SQLException e) {
            System.out.println("Error al crear tabla en MySQL: " + e.getMessage());
        }
    }    

    
}




