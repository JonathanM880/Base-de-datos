package com.suarez;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import java.io.*;
import java.util.*;

import com.fasterxml.jackson.databind.ObjectMapper;

public class DbRedis {
    private JedisPool jedisPool;
    private Jedis jedis;

    public void connectToRedis(String host, int port) {
        jedisPool = new JedisPool(new JedisPoolConfig(), host, port);
        jedis = new Jedis(host, port); // Este se usa solo para operaciones directas como sesiones
        System.out.println("Conectado a Redis");
    }

    public void disconnectFromRedis() {
        if (jedis != null) jedis.close();
        if (jedisPool != null) jedisPool.close();
    }

    // Generación de sesión en db1
    public String generarSesion() {
        jedis.select(1);  // Cambia a db1
        int random = (int) (Math.random() * Integer.MAX_VALUE);
        String key = "session:" + random;
        jedis.setex(key, 60, "valid");
        return key;
    }

    // Validación de sesión en db1
    public boolean validarSesion(String key) {
        jedis.select(1);  // Cambia a db1
        return jedis.exists(key);
    }

    // Guardar empleados en db0
    public void guardarEmpleados(List<Empleado> empleados, String clave, int segundosExpira) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(empleados);
        try (Jedis j = jedisPool.getResource()) {
            j.select(0);
            j.setex(clave, segundosExpira, json);
        }
    }

    // Recuperar empleados de db0
    public List<Empleado> recuperarEmpleados(String clave) throws IOException {
        try (Jedis j = jedisPool.getResource()) {
            j.select(0);
            String json = j.get(clave);
            if (json != null) {
                ObjectMapper mapper = new ObjectMapper();
                return Arrays.asList(mapper.readValue(json, Empleado[].class));
            }
        }
        return Collections.emptyList();
    }
}






