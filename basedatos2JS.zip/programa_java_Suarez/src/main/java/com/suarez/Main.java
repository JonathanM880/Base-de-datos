package com.suarez;

import java.io.IOException;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        long inicioTotal = System.currentTimeMillis();

        DbRedis dbRedis = new DbRedis();
        dbRedis.connectToRedis("localhost", 6379);

        try {
            long inicioSesion = System.currentTimeMillis();
            String sesion = dbRedis.generarSesion();
            if (!dbRedis.validarSesion(sesion)) {
                System.out.println("Sesión inválida.");
                dbRedis.disconnectFromRedis();
                return;
            }
            long finSesion = System.currentTimeMillis();
            System.out.println("Sesión válida. Tiempo de validación: " + (finSesion - inicioSesion) + " ms");

            Conexion conexion = new Conexion();
            conexion.conectarMySQL();

            EmpleadoSyncService servicio = new EmpleadoSyncService(conexion);
            servicio.crearTablaCache();

            String claveRedis = "empleados:consulta";
            long inicioRedis = System.currentTimeMillis();
            List<Empleado> empleados = dbRedis.recuperarEmpleados(claveRedis);
            long finRedis = System.currentTimeMillis();

            if (empleados.isEmpty()) {
                System.out.println("No hay datos en Redis. Consultando MySQL...");

                String consulta = """
                    SELECT e.emp_no, e.first_name, e.last_name, d.dept_name, s.salary
                    FROM employees e
                    JOIN dept_emp de ON e.emp_no = de.emp_no
                    JOIN departments d ON de.dept_no = d.dept_no
                    JOIN salaries s ON e.emp_no = s.emp_no
                    WHERE s.to_date > NOW()
                    LIMIT 1000
                """;

                long inicioMySQL = System.currentTimeMillis();
                empleados = servicio.obtenerEmpleados(consulta);
                long finMySQL = System.currentTimeMillis();
                System.out.println("Consulta a MySQL terminada en " + (finMySQL - inicioMySQL) + " ms");

                dbRedis.guardarEmpleados(empleados, claveRedis, 300); // 300 segundos = 5 minutos
                System.out.println("Datos guardados en Redis.");
            } else {
                System.out.println("Datos obtenidos desde Redis en " + (finRedis - inicioRedis) + " ms");
            }

            long inicioInsert = System.currentTimeMillis();
            servicio.insertarEmpleadosBatch(empleados);
            long finInsert = System.currentTimeMillis();
            System.out.println("Inserción en MySQL completada en " + (finInsert - inicioInsert) + " ms");

            conexion.desconectar();
        } catch (IOException e) {
            System.err.println("Error al trabajar con Redis: " + e.getMessage());
        } finally {
            dbRedis.disconnectFromRedis();
        }

        long finTotal = System.currentTimeMillis();
        System.out.println("Tiempo total de ejecución: " + (finTotal - inicioTotal) + " ms");
    }
}






