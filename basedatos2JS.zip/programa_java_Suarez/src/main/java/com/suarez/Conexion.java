package com.suarez;

import java.sql.*;

public class Conexion {
    private Connection connection;

    public void conectarMySQL() {
        try {
            String url = "jdbc:mysql://localhost:3340/employees"; // Ajusta si tu contenedor usa otro puerto
            String usuario = "redis";
            String contrasena = "redis";
            connection = DriverManager.getConnection(url, usuario, contrasena);
            System.out.println("Conexión exitosa a MySQL.");
        } catch (SQLException e) {
            System.out.println("Error al conectar a MySQL: " + e.getMessage());
        }
    }

    public void desconectar() {
        try {
            if (connection != null) connection.close();
        } catch (SQLException e) {
            System.out.println("Error al cerrar conexión: " + e.getMessage());
        }
    }

    public Connection getConnection() {
        return connection;
    }
}
