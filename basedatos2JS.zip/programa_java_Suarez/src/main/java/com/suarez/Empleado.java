package com.suarez;

import java.io.Serializable;

public record Empleado(
    int id,
    String nombre,
    String apellido,
    String departamento,
    int salario
) implements Serializable {}



