package com.suarez;

import java.sql.*;
import java.util.*;

public class EmpleadoSyncService {
    private final Conexion conexion;

    public EmpleadoSyncService(Conexion conexion) {
        this.conexion = conexion;
    }

    public List<Empleado> obtenerEmpleados(String sql) {
        List<Empleado> lista = new ArrayList<>();
        try (
            Statement stmt = conexion.getConnection().createStatement(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery(sql)
        ) {
            stmt.setFetchSize(Integer.MIN_VALUE);
            while (rs.next()) {
                lista.add(new Empleado(
                    rs.getInt("emp_no"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("dept_name"),
                    rs.getInt("salary")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar empleados: " + e.getMessage());
        }
        return lista;
    }

    public void insertarEmpleadosBatch(List<Empleado> empleados) {
    String sql = "REPLACE INTO empleados_cache (id, nombre, apellido, departamento, salario) VALUES (?, ?, ?, ?, ?)";
    try (PreparedStatement ps = conexion.getConnection().prepareStatement(sql)) {
        int count = 0;
        long inicio = System.currentTimeMillis();

        for (Empleado e : empleados) {
            ps.setInt(1, e.id());
            ps.setString(2, e.nombre());
            ps.setString(3, e.apellido());
            ps.setString(4, e.departamento());
            ps.setInt(5, e.salario());
            ps.addBatch();

            if (++count % 10000 == 0) {
                ps.executeBatch();
                System.out.println(count + " empleados insertados...");
            }
        }
        ps.executeBatch(); // Insertar los restantes
        long fin = System.currentTimeMillis();
        System.out.println("Tiempo total de inserción: " + (fin - inicio) + " ms");
        System.out.println("Total empleados insertados: " + count);
    } catch (SQLException e) {
        System.out.println("Error al insertar empleados: " + e.getMessage());
    }
}

    public void crearTablaCache() {
        String sql = """
            CREATE TABLE IF NOT EXISTS empleados_cache (
                id INT PRIMARY KEY,
                nombre VARCHAR(255),
                apellido VARCHAR(255),
                departamento VARCHAR(255),
                salario INT
            )
        """;
        try (Statement stmt = conexion.getConnection().createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println("Error al crear tabla cache: " + e.getMessage());
        }
    }
}
